package com.example.monage

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast
import com.example.monage.api.monageData
import com.example.monage.api.retrofitHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class updateTran : AppCompatActivity() {
    lateinit var btnUpdate: ImageButton
    lateinit var etTanggal: EditText
    lateinit var etLabel: EditText
    lateinit var etAmount: EditText
    lateinit var etDescription: EditText
    lateinit var id: String
    lateinit var closeBtn: ImageButton

    val apiKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InF0ZmpscnBmenprdGpsdW9pb2x4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE2NzEwOTA4NDYsImV4cCI6MTk4NjY2Njg0Nn0.Ja6hymC867S1KgwNoO9s04qRtu9cp2USvyD7abEAuN4"
    val token = "Bearer $apiKey"

    val monageApi =
        retrofitHelper.getInstance().create(com.example.monage.api.monageApi::class.java)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_update_tran)

        etTanggal = findViewById(R.id.dateInput_u)
        etLabel = findViewById(R.id.labelInput_u)
        etAmount = findViewById(R.id.amountInput_u)
        etDescription = findViewById(R.id.descInput_u)
        btnUpdate = findViewById(R.id.upButton)
        closeBtn = findViewById(R.id.closeBtnUp)


        id = intent.getStringExtra("id").toString()

        etTanggal.setText(intent.getStringExtra("tanggal").toString())
        etLabel.setText(intent.getStringExtra("label").toString())
        etAmount.setText(intent.getStringExtra("amount").toString())
        etDescription.setText(intent.getStringExtra("description").toString())

        btnUpdate.setOnClickListener {
            CoroutineScope(Dispatchers.Main).launch {

                val data = monageData(
                    tanggal = etTanggal.text.toString(),
                    label = etLabel.text.toString(),
                    amount = etAmount.text.toString().toDoubleOrNull()!!,
                    description = etDescription.text.toString()
                )
                val response = monageApi.update(
                    token = token,
                    apiKey = apiKey,
                    idQuery = "eq.$id",
                    monageData = data
                )

                Toast.makeText(
                    applicationContext,
                    "Berhasil merubah Transaksi!",
                    Toast.LENGTH_SHORT
                ).show()

                finish()
            }
        }
        closeBtn.setOnClickListener {
            finish()
        }
    }
}